package com.example.fileexplorer

import androidx.core.content.FileProvider

class GenericFileProvider: FileProvider(){


}